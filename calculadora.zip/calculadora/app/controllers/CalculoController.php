<?php
namespace app\controllers;
use app\core\Controller;
use app\models\Operacao;

class CalculoController extends Controller{
    public function index(){
        $dados["view"]="Home";
        $this->load("template" , $dados);
    }
    public function somar(){
        $dados["view"]="Somar";
        $this->load("template" , $dados);
        
    }
    public function calcularSoma(){
        $objOperacao= new Operacao();
        $a=$_POST["a"];
        $b=$_POST["b"];
        echo $objOperacao->somar($a, $b);

        $dados["a"]=$a;
        $dados["b"]=$b;
       $dados["resultado"]= $objOperacao->somar($a, $b);

       $dados["view"]= "Somar";
       $this->load("template", $dados);
    }
    public function multiplicar(){
        $dados["view"]="Multiplicar";
        $this->load("template" , $dados);
    }
    public function calcularMultiplicacao(){
        $objOperacao= new Operacao();
        $a=$_POST["a"];
        $b=$_POST["b"];
        echo $objOperacao->multiplicar($a, $b);

        $dados["a"]=$a;
        $dados["b"]=$b;
       $dados["resultado"]= $objOperacao->multiplicar($a, $b);

       $dados["view"]= "Multiplicar";
       $this->load("template", $dados);
    }
    public function subtrair(){
        $dados["view"]="Subtrair";
        $this->load("template" , $dados);
    }
    public function calcularSubtracao(){
        $objOperacao= new Operacao();
        $a=$_POST["a"];
        $b=$_POST["b"];
        echo $objOperacao->subtrair($a, $b);

        $dados["a"]=$a;
        $dados["b"]=$b;
       $dados["resultado"]= $objOperacao->subtrair($a, $b);

       $dados["view"]= "Subtrair";
       $this->load("template", $dados);
    }
    public function dividir(){
        $dados["view"]="Dividir";
        $this->load("template" , $dados);
    }
    public function calcularDivisao(){
        $objOperacao= new Operacao();
        $a=$_POST["a"];
        $b=$_POST["b"];
        echo $objOperacao->dividir($a, $b);

        $dados["a"]=$a;
        $dados["b"]=$b;
       $dados["resultado"]= $objOperacao->dividir($a, $b);

       $dados["view"]= "Dividir";
       $this->load("template", $dados);
    }
}
