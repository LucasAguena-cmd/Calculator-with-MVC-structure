<?php
namespace app\controllers;
use app\core\Controller;

class HomeController extends Controller{
    
   public function index(){
    $viewData=array();

       $this->load("template", ['view'=>'home']);
   } 
}
