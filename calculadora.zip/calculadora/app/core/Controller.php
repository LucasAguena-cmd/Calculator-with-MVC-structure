<?php
namespace app\core;

class Controller{
     public function load($viewName, $viewData=array()){
      if(!empty($viewData)){
       extract($viewData);}
       include "app/views/" . $viewName .".php";
   }
}
