<div class="base-cabecalho">
			
			<nav>
				<a href="<?php echo URL_BASE . "calculo"?>">Home</a>
				<a href="<?php echo URL_BASE . "calculo/somar"?>">Somar</a>
				<a href="<?php echo URL_BASE . "calculo/multiplicar"?>">Multiplicar</a>
				<a href="<?php echo URL_BASE . "calculo/dividir"?>">Dividir</a>
				<a href="<?php echo URL_BASE . "calculo/subtrair"?>">Subtrair</a>
			</nav>
		</div>