<div class="base-somar">
		<h1>Divisão</h1>
		<form method="Post" action="<?php echo URL_BASE . 'calculo/calcularDivisao'; ?>">
			<div class="calculo">
				<div class="caixa1">
					<label>
						<span>VALOR 1</span>
						<input type="text" value="<?php echo isset($a) ? $a : ""?>" name="a" placeholder="0">
					</label>
						<h2>÷</h2>
					</label>
						<span>VALOR 2</span>
						<input type="text" value="<?php echo isset($b) ? $b : ""?>" name="b" placeholder="0">
					</label>
				</div>
				<div class="caixa2">
					<input type="submit" value=" = " class="btn dividir">
				</div>
			</div>			
			<label>
			<span>resultado:</span>
			<?php if (isset($resultado)){ ?>
			<h1 class="resultado"><?php echo "<p> O resultado é: $resultado </p>"; ?></h1>
			</label>   		 
   			<?php }?>	
		</form>
	</div>