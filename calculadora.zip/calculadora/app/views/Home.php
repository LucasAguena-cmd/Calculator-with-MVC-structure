<div class="base-inicial">
			<h1>Sistema de calculos</h1>
			<span>Selecione um tipo de operação abaixo</span>
			<div class="caixa">
				<a href="<?php echo URL_BASE . "calculo/somar"?>" class="btn soma">Somar <b>+</b></a>
				<a href="<?php echo URL_BASE . "calculo/multiplicar"?>" class="btn multiplicar">Multiplicar <b>*</b></a>
				<a href="<?php echo URL_BASE . "calculo/dividir"?>" class="btn dividir">Dividir <b>÷</b></a>
				<a href="<?php echo URL_BASE . "calculo/subtrair"?>" class="btn subtrair">Subtrair <b>-</b></a>
			</div>
			</form>
		</div>