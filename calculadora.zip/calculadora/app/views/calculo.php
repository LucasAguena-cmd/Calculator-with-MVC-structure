<html>
<body>
    <h1>Sistema Calculadora</h1>
   <form method="Post" action="<?php echo URL_BASE . 'calculo/somar'; ?>">
    Valor de a: <input type="text" name="a" value="<?php echo isset($a) ? $a : ""?>">
    Valor de b: <input type="text" name="b" value="<?php echo isset($b) ? $b : ""?>">
    <input type="submit" value="enviar">
   </form>
   <?php if (isset($resultado)){
    echo "<p> O resultado é: $resultado </p>";
   }?>
</body>
</html>
