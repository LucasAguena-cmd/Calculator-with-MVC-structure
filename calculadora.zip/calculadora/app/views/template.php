<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>mjailton - ligando você ao mundo do conhecimento</title>
  	<link  rel="stylesheet" href="<?php echo URL_BASE?>assets/css/style.css">
</head>
<body>
	<div class="conteudo">
		<?php include_once "Cabecalho.php"; ?>
		<?php $this->load($view,$viewData) ?>
		
		<?php include_once "Rodape.php"?>
	</div>
</body>
</html>