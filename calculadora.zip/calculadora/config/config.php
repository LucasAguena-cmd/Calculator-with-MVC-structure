<?php

define("SERVIDOR", "localhost");
define("BANCO", "portoseguro_paginacao");
define("USUARIO", "root");
define("SENHA", "");


define('CONTROLLER_PADRAO', 'home');
define('METODO_PADRAO', 'index');
define('NAMESPACE_CONTROLLER', 'app\\controllers\\');

define('URL_BASE', 'http://localhost/estuo%20php/calculadora/');
